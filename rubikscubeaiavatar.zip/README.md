# Rubik's Cube AI Avatar Agent

A fully operational voice-to-voice avatar agent powered by a 3D Rubik's Cube that responds with emotion and dynamic movements.

## Features

- **Voice-to-Voice Conversation**: Seamless real-time voice interaction using Vapi AI
- **Emotional Intelligence**: The cube expresses emotions through complex movement patterns
- **Dual Movement Channels**:
  - **Channel A**: Individual face rotations (3x3 horizontal and vertical)
  - **Channel B**: Whole cube rotations (360° in all directions)
- **Real-time Transcript**: Live display of conversation
- **Emotion Analysis**: Automatically detects sentiment and adjusts cube behavior

## Setup

### 1. Install Dependencies

\`\`\`bash
npm install
\`\`\`

### 2. Configure Environment Variables

You need to set up Vapi AI to enable voice functionality:

1. Sign up at [Vapi AI](https://vapi.ai)
2. Create an assistant in the Vapi dashboard
3. Get your Public API Key and Assistant ID
4. Add them to your Vercel project environment variables:

**Required Environment Variables:**

- `VAPI_PUBLIC_KEY` - Your Vapi public API key
- `VAPI_ASSISTANT_ID` - Your Vapi assistant ID

**Note:** Do NOT use the `NEXT_PUBLIC_` prefix for these variables. The application uses a server component to securely pass these values to the client.

### 3. Run the Development Server

\`\`\`bash
npm run dev
\`\`\`

Open [http://localhost:3000](http://localhost:3000) to see the avatar in action.

## How It Works

### Emotion System

The cube responds to conversation with different emotions:

- **Neutral**: Centered, calm position
- **Happy**: Gentle wobbling and rotation
- **Thinking**: Slow, deliberate rotations with face twists
- **Excited**: Quick spins and multiple face rotations
- **Confused**: Tilting back and forth
- **Listening**: Subtle nodding movements
- **Surprised**: Quick backward tilt with rotation
- **Calm**: Smooth, flowing movements

### Voice Integration

The system uses Vapi AI for:
- Real-time speech-to-text
- AI-powered responses
- Text-to-speech output
- Conversation state management

### Movement Patterns

Each emotion triggers a unique sequence of movements combining:
- Whole cube rotations (X, Y, Z axes)
- Individual face twists (standard Rubik's cube notation)
- Smooth spring-based animations

## Customization

### Adding New Emotions

Edit `lib/emotion-engine.ts` to add new emotion patterns:

\`\`\`typescript
export const EMOTION_PATTERNS: Record<EmotionType, MovementPattern[]> = {
  yourEmotion: [
    { type: "rotate", axis: "y", angle: 0.5 },
    { type: "twist", axis: "x", layer: 1, direction: 1 },
  ],
}
\`\`\`

### Adjusting Animation Speed

Modify the spring configuration in `components/rubiks-cube.tsx`:

\`\`\`typescript
config: { tension: 200, friction: 20 }
\`\`\`

## Technologies

- **Next.js 15** - React framework
- **Three.js** - 3D graphics
- **React Three Fiber** - React renderer for Three.js
- **React Spring** - Animation library
- **Vapi AI** - Voice-to-voice AI platform
- **TypeScript** - Type safety
- **Tailwind CSS** - Styling

## License

MIT
